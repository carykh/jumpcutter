I just finished using subtitles to auto cut. 

But now most of the comments in the code are in Chinese, so you may look it messy. 

there is a test video file included. 

so you just run the command below, you can see the outwork:

```
pip install -r requirements.txt
python jumpcutter.py --input_file "autocut.mp4" --input_subtitle "autocut.srt" --frame_margin 2
```

a auto-cutted video will be generated.

If you are a non-Chinese user, you may need to clean up the comments, and designate another  **cutKeyword** and  **saveKeyword** , and you need to find a internet service to automaticlly generate a srt subtitle. 

Enjoy! 



